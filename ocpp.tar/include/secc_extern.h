#ifndef _SECC_EXTERN_H
#define _SECC_EXTERN_H

#include "ocpp.h"

extern secc_ocpp_actions so_actions[] ;
#endif